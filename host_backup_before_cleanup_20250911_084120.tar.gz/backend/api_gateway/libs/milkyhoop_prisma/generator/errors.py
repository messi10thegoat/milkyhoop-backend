from ..errors import PrismaError


class TemplateError(PrismaError):
    pass


class PartialTypeGeneratorError(PrismaError):
    pass
