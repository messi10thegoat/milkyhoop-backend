import json
import os
import uuid
from datetime import datetime
from typing import Dict, List, Optional

import requests
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from backend.api_gateway.app.services.chatbot_client import ChatbotClient
from backend.api_gateway.app.services.ragcrud_client import RagCrudClient
from backend.api_gateway.app.services.ragllm_client import RagLLMClient
from backend.api_gateway.app.services.tenant_client import TenantParserClient
# from backend.api_gateway.app.services.context_client import ContextClient

import logging

# 🔧 TEMPLATE RESOLUTION FUNCTION
def resolve_template_variables(text: str, context: dict) -> str:
    """
    Resolve template variables in response text
    
    Replaces {{variable}} patterns with actual values from context
    """
    if not text or "{{" not in text:
        return text
        
    # Common template variable mappings
    template_mappings = {
        "{{message}}": context.get("message", context.get("query", "")),
        "{{query}}": context.get("query", context.get("message", "")),
        "{{tenant_id}}": context.get("tenant_id", ""),
        "{{business_name}}": context.get("business_name", context.get("tenant_id", "")),
        "{{user_query}}": context.get("message", context.get("query", ""))
    }
    
    resolved_text = text
    for template, value in template_mappings.items():
        if template in resolved_text:
            resolved_text = resolved_text.replace(template, str(value))
            
    # Handle complex nested templates like {{input.entities.MenuItems.price}}
    import re
    complex_templates = re.findall(r"{{[^}]+}}", resolved_text)
    for template in complex_templates:
        # Replace remaining unresolved templates with helpful message
        resolved_text = resolved_text.replace(template, "informasi tidak tersedia")
        
    return resolved_text
logger = logging.getLogger(__name__)

router = APIRouter()

# 📊 REQUEST/RESPONSE MODELS
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    visitor_id: Optional[str] = None

class ChatResponse(BaseModel):
    status: str
    tenant_id: str
    business_name: Optional[str] = None
    response: str
    reply: Optional[str] = None
    session_id: str
    trace_id: str
    intent: Optional[str] = None

# 🔧 UTILITY FUNCTIONS
def generate_trace_id() -> str:
    """Generate unique trace ID"""
    return str(uuid.uuid4())[:8]

# 🎯 CUSTOMER MODE - FIXED FLOW EXECUTOR PATTERN
async def call_flow_executor(profile_id: str, query: str, trace_id: str, entities: Dict, intent: str, session_id: str) -> Dict:    
    """
    Call Flow Executor for customer inquiries - FIXED VERSION
    
    Uses same pattern as working version but with proper entity structure
    """
    try:
        logger.info(f"[FLOW-{trace_id}] Executing customer flow for {profile_id}")
        
        # Use enhanced payload structure from working version
        payload = {
            "input": {
                "user_id": f"customer_{session_id}",
                "tenant_id": profile_id,
                "query": query,
                "entities": entities,
                "intent": intent,
                "trace_id": trace_id,
                "timestamp": datetime.now().isoformat(),
                "customer_query": query  # Match flow template
            }
        }
        
        # Primary flow execution
        response = requests.post(
            f"http://flow-executor:8088/run-flow/customer-inquiry-handler.json",
            json=payload,
            timeout=30,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            logger.info(f"[FLOW-{trace_id}] ✅ Flow Executor completed successfully")
            logger.info(f"[DEBUG-{trace_id}] Flow result: {result}")
            
            # Validate response structure
            if not isinstance(result, dict):
                logger.warning(f"[FLOW-{trace_id}] Invalid response format from flow executor")
                return {"status": "error", "message": "Invalid response format"}
            
            return result
            
        elif response.status_code == 404:
            logger.error(f"[FLOW-{trace_id}] Flow file not found - falling back to direct processing")
            return fallback_direct_processing(profile_id, query, trace_id)
            
        else:
            logger.error(f"[FLOW-{trace_id}] Flow Executor error: {response.status_code} - {response.text}")
            return fallback_direct_processing(profile_id, query, trace_id)
            
    except requests.exceptions.Timeout:
        logger.error(f"[FLOW-{trace_id}] Flow Executor timeout - attempting fallback")
        return fallback_direct_processing(profile_id, query, trace_id)
        
    except requests.exceptions.ConnectionError:
        logger.error(f"[FLOW-{trace_id}] Flow Executor connection failed - service unavailable")
        return fallback_direct_processing(profile_id, query, trace_id)
        
    except Exception as e:
        logger.error(f"[FLOW-{trace_id}] Unexpected error in flow execution: {str(e)}")
        return fallback_direct_processing(profile_id, query, trace_id)

async def fallback_direct_processing(profile_id: str, query: str, trace_id: str) -> Dict:
    """
    Direct RAG Processing Fallback - Returns actual FAQ content
    
    When flow executor fails, call RAG LLM directly for customer service
    """
    try:
        logger.info(f"[FALLBACK-{trace_id}] Initiating direct RAG processing for {profile_id}")
        
        # Call RAG LLM service directly with customer context
        rag_client = RagLLMClient()
        answer = await rag_client.generate_answer(
            user_id=f"customer_{trace_id}",
            session_id=trace_id,
            tenant_id=profile_id,
            message=query  # Direct customer question, not setup context
        )
        
        logger.info(f"[FALLBACK-{trace_id}] ✅ Direct RAG processing successful")
        return {
            "result": {
                "message": answer
            },
            "status": "success",
            "source": "direct_rag"
        }
            
    except Exception as e:
        logger.error(f"[FALLBACK-{trace_id}] Fallback processing failed: {str(e)}")
        return {
            "result": {
                "message": "Maaf, tidak dapat memproses permintaan saat ini."
            },
            "status": "error", 
            "source": "fallback_error"
        }

# 🤖 CUSTOMER CHAT ENDPOINT - FIXED VERSION
@router.post("/{tenant_id}/chat")
async def customer_chat(tenant_id: str, data: ChatRequest):
    """
    Customer chat with AI assistant - FIXED CUSTOMER MODE
    
    Flow: Customer Query → Tenant Parser → Flow Executor → Direct FAQ Response
    """
    trace_id = generate_trace_id()
    session_id = data.session_id or str(uuid.uuid4())
    customer_user_id = f"customer_{session_id}"
    
    logger.info(f"[{trace_id}] 💬 Customer chat: tenant={tenant_id}, message='{data.message[:50]}...'")
    
    try:
        # STEP 1: Context Resolution (Multi-turn support)
        resolved_message = data.message
        try:
            async with ContextClient() as context_client:
                context_result = await context_client.resolve_reference(
                    message=data.message,
                    session_id=session_id,
                    tenant_id=tenant_id
                )
                resolved_message = context_result.get("resolved_message", data.message)
                resolved_references = context_result.get("references", [])
                
                if resolved_references:
                    logger.info(f"[{trace_id}] 🔗 References resolved: {len(resolved_references)} items")
        except Exception as e:
            logger.warning(f"[{trace_id}] ⚠️ Context resolution failed: {e}")
            resolved_message = data.message

        # STEP 2: Call Tenant Parser - CUSTOMER MODE
        logger.info(f"[{trace_id}] 🧠 Step 2: Calling Tenant Parser")
        tenant_client = TenantParserClient()
        parsed = await tenant_client.parse_customer_query(
            tenant_id=tenant_id, 
            message=resolved_message, session_id=session_id
        )
        
        intent = parsed.get("intent", "customer_inquiry")
        entities_raw = parsed.get("entities", {})
        
        # Parse entities safely
        entities = entities_raw if isinstance(entities_raw, dict) else {}
        
        # CRITICAL FIX: Use tenant_parser answer directly if available
        tenant_answer = parsed.get("answer", "")
        tenant_confidence = parsed.get("confidence", 0.0)
        
        logger.info(f"[{trace_id}] 🎯 Tenant Parser Response: intent={intent}, confidence={tenant_confidence:.3f}")
        
        # Use tenant_parser answer directly for high confidence responses
        if tenant_answer and tenant_confidence > 0.1:
            logger.info(f"[{trace_id}] ✅ Using tenant_parser answer directly (confidence: {tenant_confidence:.3f})")
            
            # Load business profile for context
            profile_path = f"data/tenant_profiles/{tenant_id}.json"
            business_name = tenant_id
            
            if os.path.exists(profile_path):
                try:
                    with open(profile_path, "r") as f:
                        profile = json.load(f)
                        business_name = profile.get("business_name", tenant_id)
                except:
                    pass
            
            return ChatResponse(
                status="success",
                tenant_id=tenant_id,
                business_name=business_name,
                response=tenant_answer,
            reply=tenant_answer,
                session_id=session_id,
                trace_id=trace_id,
                intent=intent
            )
        
        
        logger.info(f"[{trace_id}] 🎯 Customer Intent: {intent}, Entities: {len(entities)} items")
        
        # STEP 3: Route to Flow Executor - FIXED VERSION
        logger.info(f"[{trace_id}] ⚡ Step 3: Calling Flow Executor")
        flow_result = await call_flow_executor(
            profile_id=tenant_id,
            query=data.message,
            trace_id=trace_id,
            entities=entities,
            intent=intent,
            session_id=session_id
        )
        
        # STEP 4: Extract response from flow result - FIXED
        logger.info(f"[{trace_id}] 💬 Step 4: Processing flow response")
        
        # Handle flow execution errors with graceful degradation
        if flow_result.get("status") == "error":
            error_message = flow_result.get("message", "Flow execution failed")
            logger.error(f"[{trace_id}] Flow error: {error_message}")
            
            # Return helpful error response
            return ChatResponse(
                status="error",
                tenant_id=tenant_id,
                response="Maaf, sistem sedang mengalami gangguan. Silakan coba lagi dalam beberapa menit. 🙏",
            reply="Maaf, sistem sedang mengalami gangguan. Silakan coba lagi dalam beberapa menit. 🙏",
                session_id=session_id,
                trace_id=trace_id,
                intent="system_error"
            )
        
        # Extract response from flow result - CRITICAL FIX
        # Extract response from flow result with template resolution
        raw_response = flow_result.get("result", {}).get("answer", "") or flow_result.get("result", {}).get("message", "")
        
        # Resolve template variables
        template_context = {
            "message": data.message,
            "query": data.message,
            "tenant_id": tenant_id,
            "business_name": tenant_id,
            "session_id": session_id
        }
        response_text = resolve_template_variables(raw_response, template_context)
        if not response_text:
            logger.warning(f"[{trace_id}] Empty response from flow executor")
            response_text = f"Halo! Terima kasih telah menghubungi {tenant_id}. Ada yang bisa saya bantu? 😊"
        
        # STEP 5: Load business profile for context
        profile_path = f"data/tenant_profiles/{tenant_id}.json"
        business_name = tenant_id
        
        if os.path.exists(profile_path):
            try:
                with open(profile_path, "r") as f:
                    profile = json.load(f)
                    business_name = profile.get("business_name", tenant_id)
            except:
                pass
        
        logger.info(f"[{trace_id}] ✅ Customer response generated successfully")
        
        return ChatResponse(
            status="success",
            tenant_id=tenant_id,
            business_name=business_name,
            response=response_text,
            reply=response_text,  # Direct from flow result, not RAG LLM processing
            session_id=session_id,
            trace_id=trace_id,
            intent=intent
        )
        
    except Exception as e:
        logger.error(f"[{trace_id}] ❌ Customer chat error: {e}")
        return ChatResponse(
            status="error",
            tenant_id=tenant_id,
            response="Maaf, asisten AI sedang maintenance 😅 Silakan coba lagi dalam beberapa menit.",
            reply="Maaf, asisten AI sedang maintenance 😅 Silakan coba lagi dalam beberapa menit.",
            session_id=session_id,
            trace_id=trace_id
        )

# 🏥 HEALTH CHECK
@router.get("/health")
async def health_check():
    """Health check for Customer Mode"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "customer_mode"
    }