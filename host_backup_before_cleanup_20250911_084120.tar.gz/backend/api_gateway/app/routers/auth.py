import asyncio
import logging
from typing import Dict, Any, Optional
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from backend.api_gateway.app.services.auth_client import AuthClient

logger = logging.getLogger(__name__)
router = APIRouter()

# Initialize auth client
auth_client = AuthClient()

# =====================================================
# REQUEST/RESPONSE MODELS
# =====================================================

class RegisterRequest(BaseModel):
    email: str
    password: str
    name: Optional[str] = None
    username: Optional[str] = None

class LoginRequest(BaseModel):
    email: str
    password: str

class ValidateTokenRequest(BaseModel):
    access_token: str

class AuthResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None

# =====================================================
# AUTHENTICATION ENDPOINTS
# =====================================================

@router.post("/register", response_model=AuthResponse)
async def register_user(request: RegisterRequest):
    """User registration endpoint"""
    try:
        logger.info(f"Registration request for email: {request.email}")
        
        # Connect to auth service
        await auth_client.connect()
        
        # Call registration service
        result = await auth_client.register_user(
            email=request.email,
            password=request.password,
            name=request.name,
            username=request.username
        )
        
        if result["success"]:
            return AuthResponse(
                success=True,
                message="Registration successful",
                data={
                    "user_id": result["user_id"],
                    "email": request.email,
                    "access_token": result["access_token"],
                    "refresh_token": result["refresh_token"]
                }
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result["message"]
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Registration error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Registration failed due to server error"
        )
    finally:
        await auth_client.disconnect()

@router.post("/login", response_model=AuthResponse)
async def login_user(request: LoginRequest):
    """User login endpoint"""
    try:
        logger.info(f"Login request for email: {request.email}")
        
        # Connect to auth service
        await auth_client.connect()
        
        # Call login service
        result = await auth_client.login_user(
            email=request.email,
            password=request.password
        )
        
        if result["success"]:
            return AuthResponse(
                success=True,
                message="Login successful",
                data={
                    "user_id": result["user_id"],
                    "email": result["email"],
                    "name": result["name"],
                    "role": result["role"],
                    "tenant_id": result["tenant_id"],
                    "access_token": result["access_token"],
                    "refresh_token": result["refresh_token"]
                }
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=result["message"]
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Login failed due to server error"
        )
    finally:
        await auth_client.disconnect()

@router.post("/validate", response_model=AuthResponse)
async def validate_token(request: ValidateTokenRequest):
    """Token validation endpoint"""
    try:
        logger.info("Token validation request")
        
        # Connect to auth service
        await auth_client.connect()
        
        # Call token validation service
        result = await auth_client.validate_token(request.access_token)
        
        if result["valid"]:
            return AuthResponse(
                success=True,
                message="Token is valid",
                data={
                    "user_id": result["user_id"],
                    "tenant_id": result["tenant_id"],
                    "role": result["role"],
                    "expires_at": result["expires_at"]
                }
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=result["message"]
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Token validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Token validation failed due to server error"
        )
    finally:
        await auth_client.disconnect()

@router.get("/profile/{user_id}", response_model=AuthResponse)
async def get_user_profile(user_id: str):
    """Get user profile endpoint"""
    try:
        logger.info(f"Get profile request for user: {user_id}")
        
        # Connect to auth service
        await auth_client.connect()
        
        # Call profile service
        result = await auth_client.get_user_profile(user_id)
        
        if result["success"]:
            return AuthResponse(
                success=True,
                message="Profile retrieved successfully",
                data={
                    "user_id": result["user_id"],
                    "email": result["email"],
                    "name": result["name"],
                    "username": result["username"],
                    "role": result["role"]
                }
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=result["message"]
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get profile error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Get profile failed due to server error"
        )
    finally:
        await auth_client.disconnect()

@router.get("/health")
async def auth_health_check():
    """Auth service health check"""
    try:
        await auth_client.connect()
        await auth_client.disconnect()
        return {"status": "healthy", "service": "auth"}
    except Exception as e:
        logger.error(f"Auth health check failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Auth service unavailable"
        )
