from backend.api_gateway.libs.milkyhoop_prisma import Prisma

# ✅ Prisma global instance
prisma = Prisma()
