"""
Context Service gRPC Client
"""

import grpc
import asyncio
from typing import Dict, List, Any, Optional
import os
import logging

# Import generated protobuf
import sys
sys.path.append('/app/backend/api_gateway/libs')
from milkyhoop_protos import context_service_pb2 as pb
from milkyhoop_protos import context_service_pb2_grpc as pb_grpc

logger = logging.getLogger(__name__)

class ContextClient:
    def __init__(self):
        self.host = os.getenv("CONTEXT_SERVICE_HOST", "context_service")
        self.port = os.getenv("CONTEXT_SERVICE_PORT", "5007")
        self.channel = None
        self.stub = None
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.disconnect()
    
    async def connect(self):
        """Connect to context service"""
        try:
            self.channel = grpc.aio.insecure_channel(f"{self.host}:{self.port}")
            self.stub = pb_grpc.ContextServiceStub(self.channel)
            logger.info(f"✅ Connected to context service at {self.host}:{self.port}")
        except Exception as e:
            logger.error(f"❌ Failed to connect to context service: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from context service"""
        if self.channel:
            await self.channel.close()
            logger.info("✅ Disconnected from context service")
    
    async def resolve_reference(self, message: str, session_id: str, tenant_id: str) -> Dict[str, Any]:
        """
        Resolve references in user message
        
        Returns:
        {
            "resolved_message": str,
            "references": List[Dict],
            "confidence": float,
            "success": bool,
            "suggested_intent": str  # ← NEW FIELD
        }
        """
        try:
            request = pb.ReferenceRequest(
                message=message,
                session_id=session_id,
                tenant_id=tenant_id
            )
            
            response = await self.stub.ResolveReference(request)
            
            # Convert protobuf response to dict
            references = []
            for ref in response.references:
                references.append({
                    "reference": ref.reference,
                    "entity_type": ref.entity_type,
                    "entity_id": ref.entity_id,
                    "entity_value": ref.entity_value,
                    "confidence": ref.confidence
                })
            
            return {
                "resolved_message": response.resolved_message,
                "references": references,
                "confidence": response.confidence,
                "success": response.success,
                "suggested_intent": response.suggested_intent  # ← ADD THIS LINE
            }
            
        except Exception as e:
            logger.error(f"❌ Error resolving reference: {e}")
            return {
                "resolved_message": message,
                "references": [],
                "confidence": 0.0,
                "success": False,
                "suggested_intent": ""  # ← ADD THIS LINE
            }
    
    async def store_conversation_turn(self, session_id: str, tenant_id: str, turn_data: Dict[str, Any]) -> bool:
        """
        Store conversation turn for context tracking
        
        Args:
            turn_data: {
                "user_message": str,
                "system_response": str,
                "entities": Dict[str, str],
                "resolved_references": List[Dict],
                "topic": str,
                "action": str
            }
        """
        try:
            # Convert resolved references to protobuf
            resolved_refs = []
            for ref in turn_await data.get("resolved_references", []):
                resolved_refs.append(pb.ResolvedReference(
                    reference=ref.get("reference", ""),
                    entity_type=ref.get("entity_type", ""),
                    entity_id=ref.get("entity_id", 0),
                    entity_value=ref.get("entity_value", ""),
                    confidence=ref.get("confidence", 0.0)
                ))
            
            request = pb.ConversationTurnRequest(
                session_id=session_id,
                tenant_id=tenant_id,
                user_message=turn_await data.get("user_message", ""),
                system_response=turn_await data.get("system_response", ""),
                entities=turn_await data.get("entities", {}),
                resolved_references=resolved_refs,
                topic=turn_await data.get("topic", ""),
                action=turn_await data.get("action", "")
            )
            
            response = await self.stub.StoreConversationTurn(request)
            
            if response.success:
                logger.info("✅ Conversation turn stored successfully")
            else:
                logger.warning(f"⚠️ Failed to store conversation turn: {response.message}")
            
            return response.success
            
        except Exception as e:
            logger.error(f"❌ Error storing conversation turn: {e}")
            return False
    
    async def get_proactive_data(self, topics: List[str], tenant_id: str) -> Dict[str, Any]:
        """
        Get proactive business data based on topics
        
        Returns:
        {
            "pricing": {...},
            "operating_hours": {...},
            "location": {...}
        }
        """
        try:
            request = pb.ProactiveDataRequest(
                topics=topics,
                tenant_id=tenant_id
            )
            
            response = await self.stub.GetProactiveData(request)
            
            if not response.success:
                logger.warning("⚠️ Failed to get proactive data")
                return {}
            
            # Convert protobuf response to dict
            proactive_data = {}
            for key, business_data in response.data.items():
                proactive_data[key] = {
                    "data_type": business_data.data_type,
                    "current_value": business_data.current_value,
                    "source": business_data.source,
                    "last_updated": business_data.last_updated,
                    "search_terms": list(business_data.search_terms)
                }
            
            logger.info(f"✅ Retrieved proactive data for {len(topics)} topics")
            return proactive_data
            
        except Exception as e:
            logger.error(f"❌ Error getting proactive data: {e}")
            return {}

# Usage example
async def test_context_client():
    """Test context client functionality"""
    async with ContextClient() as client:
        # Test reference resolution
        result = await client.resolve_reference(
            message="yang tadi berapa sekarang?",
            session_id="test-session",
            tenant_id="test-tenant"
        )
        print(f"Reference resolution result: {result}")
        
        # Test proactive data
        data = await client.get_proactive_data(
            topics=["harga", "jam buka"],
            tenant_id="test-tenant"
        )
        print(f"Proactive data: {data}")

if __name__ == "__main__":
    asyncio.run(test_context_client())
